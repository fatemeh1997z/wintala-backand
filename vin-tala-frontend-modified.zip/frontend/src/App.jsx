import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "./lib/auth.jsx";
import { RealtimeProvider } from "./lib/realtime.jsx";

import Layout from "./ui/Layout.jsx";
import "./styles.css";
import Home from "./pages/Home.jsx";
import Explore from "./pages/Explore.jsx";
import Product from "./pages/Product.jsx";
import Cart from "./pages/Cart.jsx";
import Profile from "./pages/Profile.jsx";
import Orders from "./pages/Orders.jsx";
import Savings from "./pages/Savings.jsx";
import CustomBuild from "./pages/CustomBuild.jsx";
import AdminProducts from "./pages/AdminProducts.jsx";
import StaticPage from "./pages/StaticPage.jsx";
import PaymentSuccess from "./pages/PaymentSuccess.jsx";

function Guard({ children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/profile" replace />;
  return children;
}

export default function App() {
  return (
    <AuthProvider>
      <AppInner />
    </AuthProvider>
  );
}

function AppInner(){
  const { token, user } = useAuth();
  return (
    <RealtimeProvider token={token}>
      <Layout user={user}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/explore" element={<Explore />} />
          <Route path="/product/:id" element={<Product />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/orders" element={<Guard><Orders /></Guard>} />
          <Route path="/savings" element={<Guard><Savings /></Guard>} />
          <Route path="/custom-build" element={<Guard><CustomBuild /></Guard>} />
          <Route path="/admin/products" element={<Guard><AdminProducts /></Guard>} />
          <Route path="/payment/success" element={<PaymentSuccess />} />
          <Route path="/about" element={<StaticPage kind="about" />} />
          <Route path="/contact" element={<StaticPage kind="contact" />} />
          <Route path="/licenses" element={<StaticPage kind="licenses" />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </RealtimeProvider>
  );
}

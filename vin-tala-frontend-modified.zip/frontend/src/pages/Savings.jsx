import React, { useEffect, useMemo, useState } from "react";
import { api, money } from "../lib/api.js";
import { Line } from "react-chartjs-2";
import {
  Chart as ChartJS,
  LineElement,
  PointElement,
  CategoryScale,
  LinearScale,
  Tooltip,
  Legend
} from "chart.js";

ChartJS.register(LineElement, PointElement, CategoryScale, LinearScale, Tooltip, Legend);

export default function Savings(){
  const [wallet, setWallet] = useState(null);
  const [amount, setAmount] = useState(500000);
  const [analytics, setAnalytics] = useState(null);

  async function load(){
    const w = await api.get("/savings");
    setWallet(w.data.wallet);
    const a = await api.get("/analytics/profit-series");
    setAnalytics(a.data);
  }
  useEffect(()=>{ load(); }, []);

  async function buy(){
    await api.post("/savings/buy", { amount_toman: Number(amount) });
    load();
  }

  const chart = useMemo(() => {
    if (!analytics?.series?.length) return null;
    const labels = analytics.series.map(p => new Date(p.t).toLocaleDateString("fa-IR"));
    const data = analytics.series.map(p => p.profit_toman);

    return {
      data: {
        labels,
        datasets: [
          { label: "سود/زیان (تومان)", data, tension: 0.25 }
        ]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: true } },
        scales: { y: { ticks: { callback: (v) => Number(v).toLocaleString("fa-IR") } } }
      }
    };
  }, [analytics]);

  return (
    <div className="grid" style={{gridTemplateColumns:"0.9fr 1.1fr", gap:12}}>
      <div className="card">
        <h2 style={{margin:"6px 0"}}>پس‌انداز طلا</h2>
        <div className="small">با کمترین مبلغ، طلا پس‌انداز کنید و موقع خرید از طلای پس‌انداز شده استفاده کنید.</div>
        <hr />
        <div className="row">
          <span className="badge">موجودی: <b style={{color:"var(--accent)"}}>{(wallet?.gold_g || 0).toLocaleString("fa-IR", {maximumFractionDigits:4})}</b> گرم</span>
          <span className="badge">میانگین خرید: <b>{money(wallet?.avg_cost_per_g || 0)}</b> تومان/گرم</span>
        </div>
        <hr />
        <label>خرید طلا برای پس‌انداز (تومان)</label>
        <input className="input" value={amount} onChange={(e)=>setAmount(e.target.value)} />
        <div className="row" style={{marginTop:10}}>
          <button className="btn success" onClick={buy}>تبدیل پول به طلا</button>
        </div>
        <div className="small" style={{marginTop:10}}>
          * این یک مدل ساده برای MVP است. در نسخه واقعی باید فرآیندهای مالی/حسابداری و قوانین تطبیق را تکمیل کنید.
        </div>
      </div>

      <div className="card">
        <h3 style={{margin:"6px 0"}}>نمودار سود خریدار (آنلاین)</h3>
        <div className="small">بر اساس قیمت‌های ثبت‌شده و میزان دارایی تخمینی.</div>
        <hr />
        {!chart ? (
          <div className="small">داده کافی برای نمودار موجود نیست (کمی صبر کنید تا تاریخچه قیمت جمع شود).</div>
        ) : (
          <Line data={chart.data} options={chart.options} />
        )}
        <div className="row" style={{marginTop:10}}>
          <span className="badge">دارایی تخمینی: <b>{(analytics?.holdings_g || 0).toLocaleString("fa-IR", {maximumFractionDigits:2})}</b> گرم</span>
          <span className="badge">قیمت فعلی: <b>{money(analytics?.current?.price_per_g || 0)}</b> تومان/گرم</span>
        </div>
      </div>
    </div>
  );
}

import React, { useEffect, useState } from "react";
import { api, money, gram, API_BASE } from "../lib/api.js";
import { useAuth } from "../lib/auth.jsx";

export default function Orders(){
  const { user } = useAuth();
  const [items, setItems] = useState([]);
  const [selected, setSelected] = useState(null);

  async function load(){
    const r = await api.get("/orders");
    setItems(r.data.items || []);
  }
  useEffect(() => { load(); }, []);

  async function open(id){
    const r = await api.get(`/orders/${id}`);
    setSelected(r.data);
  }

  const canInvoice = (st) => ["paid","processing","shipped","ready_for_pickup","completed"].includes(st);

  return (
    <div className="grid" style={{gridTemplateColumns:"0.9fr 1.1fr", gap:12}}>
      <div className="card">
        <h2 style={{margin:"6px 0"}}>سابقه سفارش‌ها</h2>
        <div className="small">نمایش سفارش‌های شما (خریدار) یا سفارش‌های مربوط به شما (فروشنده).</div>
        <hr />
        {items.length ? items.map(o => (
          <button key={o.id} className="btn" style={{width:"100%", textAlign:"right", marginBottom:8}} onClick={()=>open(o.id)}>
            <div className="row" style={{justifyContent:"space-between", alignItems:"center"}}>
              <b>سفارش #{o.id}</b>
              <span className="badge">{o.status}</span>
            </div>
            <div className="small">مبلغ: {money(o.total_amount)} تومان • {o.shipping_method === "pickup" ? "حضوری" : "پست"}</div>
          </button>
        )) : <div className="small">سفارشی ندارید.</div>}
      </div>

      <div className="card">
        {!selected ? (
          <div className="small">برای مشاهده جزئیات، یک سفارش را انتخاب کنید.</div>
        ) : (
          <div>
            <div className="row" style={{justifyContent:"space-between", alignItems:"center"}}>
              <h3 style={{margin:"6px 0"}}>جزئیات سفارش #{selected.order.id}</h3>
              <span className="badge">{selected.order.status}</span>
            </div>
            <div className="row">
              <span className="badge">روش دریافت: <b>{selected.order.shipping_method === "pickup" ? "دریافت حضوری" : "پست کالا"}</b></span>
              <span className="badge">قیمت لحظه‌ای: <b>{money(selected.order.gold_price_per_g)}</b> تومان/گرم</span>
            </div>
            {selected.order.shipping_method === "post" ? (
              <div className="small" style={{marginTop:8}}>آدرس: {selected.order.shipping_address}</div>
            ) : null}

            <hr />
            <h4 style={{margin:"6px 0"}}>اقلام</h4>
            <div className="grid" style={{gap:8}}>
              {selected.items.map((it, idx) => (
                <div key={idx} className="card" style={{padding:12}}>
                  <div className="row" style={{justifyContent:"space-between"}}>
                    <b>{it.name}</b>
                    <span className="badge">{it.category}</span>
                  </div>
                  <div className="small">وزن: {gram(it.weight_g)} گرم • تعداد: {it.qty}</div>
                  <div className="badge">قیمت واحد: <b style={{color:"var(--accent)"}}>{money(it.unit_price)}</b> تومان</div>
                </div>
              ))}
            </div>

            <hr />
            <div className="row">
              <span className="badge">جمع جزء: <b>{money(selected.order.subtotal_amount)}</b></span>
              <span className="badge">کارمزد ۲٪: <b>{money(selected.order.fee_amount)}</b></span>
              <span className="badge">نهایی: <b style={{color:"var(--accent)"}}>{money(selected.order.total_amount)}</b></span>
            </div>

            <div className="row" style={{marginTop:12}}>
              {canInvoice(selected.order.status) ? (
                <a className="btn primary" href={`${API_BASE}/api/orders/${selected.order.id}/invoice`} target="_blank" rel="noreferrer">
                  دانلود فاکتور رسمی با ضمانت (PDF)
                </a>
              ) : (
                <span className="small">فاکتور بعد از پرداخت قابل دریافت است.</span>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

import React, { useEffect, useState } from "react";
import { api } from "../lib/api.js";
import { useRealtime } from "../lib/realtime.jsx";

export default function CustomBuild(){
  const rt = useRealtime();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [weight, setWeight] = useState("");
  const [budget, setBudget] = useState("");
  const [items, setItems] = useState([]);

  async function load(){
    const r = await api.get("/custom-requests");
    setItems(r.data.items || []);
  }
  useEffect(()=>{ load(); }, []);

  async function submit(){
    const r = await api.post("/custom-requests", {
      title, description,
      target_weight_g: weight ? Number(weight) : undefined,
      budget_toman: budget ? Number(budget) : undefined
    });
    rt?.pushToast?.("درخواست ساخت", `درخواست #${r.data.id} ثبت شد.`);
    setTitle(""); setDescription(""); setWeight(""); setBudget("");
    load();
  }

  return (
    <div className="grid" style={{gridTemplateColumns:"1fr 1fr", gap:12}}>
      <div className="card">
        <h2 style={{margin:"6px 0"}}>دریافت سفارش ساخت طلای مد نظر</h2>
        <div className="small">مدل، وزن، بودجه و توضیحات را ثبت کنید تا بررسی شود.</div>
        <hr />
        <label>عنوان</label>
        <input className="input" value={title} onChange={(e)=>setTitle(e.target.value)} placeholder="مثلاً: انگشتر طرح خاص" />
        <div style={{height:10}} />
        <label>توضیحات</label>
        <textarea className="input" rows="4" value={description} onChange={(e)=>setDescription(e.target.value)} placeholder="جزئیات طرح، اندازه، عکس/لینک، زمان تحویل..." />
        <div style={{height:10}} />
        <div className="grid" style={{gridTemplateColumns:"1fr 1fr", gap:10}}>
          <div>
            <label>وزن هدف (گرم - اختیاری)</label>
            <input className="input" value={weight} onChange={(e)=>setWeight(e.target.value)} />
          </div>
          <div>
            <label>بودجه (تومان - اختیاری)</label>
            <input className="input" value={budget} onChange={(e)=>setBudget(e.target.value)} />
          </div>
        </div>
        <div className="row" style={{marginTop:12}}>
          <button className="btn primary" onClick={submit} disabled={!title.trim() || description.trim().length < 10}>
            ثبت درخواست
          </button>
        </div>
      </div>

      <div className="card">
        <h3 style={{margin:"6px 0"}}>سوابق درخواست‌های شما</h3>
        <hr />
        {items.length ? items.map(x => (
          <div key={x.id} className="card" style={{marginBottom:10}}>
            <div className="row" style={{justifyContent:"space-between"}}>
              <b>#{x.id} • {x.title}</b>
              <span className="badge">{x.status}</span>
            </div>
            <div className="small" style={{marginTop:6}}>{x.description}</div>
            <div className="row" style={{marginTop:8}}>
              {x.target_weight_g ? <span className="badge">وزن: {x.target_weight_g}g</span> : null}
              {x.budget_toman ? <span className="badge">بودجه: {Number(x.budget_toman).toLocaleString("fa-IR")} تومان</span> : null}
            </div>
          </div>
        )) : <div className="small">هنوز درخواستی ثبت نشده.</div>}
      </div>
    </div>
  );
}

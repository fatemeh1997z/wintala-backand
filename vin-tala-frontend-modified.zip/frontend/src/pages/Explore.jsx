import React, { useEffect, useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import { api, money, gram } from "../lib/api.js";

const cats = ["", "گوشواره","النگو","انگشتر","گردنبند","دستبند","سرویس","زنجیر","آویز","سکه","شمش","پک سرمایه‌گذاری"];

export default function Explore(){
  const [sp, setSp] = useSearchParams();
  const [items, setItems] = useState([]);
  const [gold, setGold] = useState(0);
  const [loading, setLoading] = useState(false);

  const filters = useMemo(() => ({
    q: sp.get("q") || "",
    category: sp.get("category") || "",
    minPrice: sp.get("minPrice") || "",
    maxPrice: sp.get("maxPrice") || "",
    minWeight: sp.get("minWeight") || "",
    maxWeight: sp.get("maxWeight") || ""
  }), [sp]);

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    params.set("active","1");
    if (filters.q) params.set("q", filters.q);
    if (filters.category) params.set("category", filters.category);
    if (filters.minPrice) params.set("minPrice", filters.minPrice);
    if (filters.maxPrice) params.set("maxPrice", filters.maxPrice);
    if (filters.minWeight) params.set("minWeight", filters.minWeight);
    if (filters.maxWeight) params.set("maxWeight", filters.maxWeight);

    api.get("/products?" + params.toString())
      .then(r => { setItems(r.data.items || []); setGold(r.data.gold_price_per_g || 0); })
      .finally(()=> setLoading(false));
  }, [filters]);

  function update(k, v){
    const n = new URLSearchParams(sp);
    if (!v) n.delete(k); else n.set(k, v);
    setSp(n, { replace: true });
  }

  return (
    <div>
      <div className="row" style={{justifyContent:"space-between", alignItems:"center"}}>
        <h2 style={{margin:"6px 0"}}>اکسپلور • گشت‌وگذار برای طلا</h2>
        <div className="badge">قیمت لحظه‌ای: <b style={{color:"var(--accent)"}}>{money(gold)}</b> تومان / گرم</div>
      </div>

      <div className="card" style={{marginTop:10}}>
        <div className="grid" style={{gridTemplateColumns:"2fr 1fr 1fr 1fr", alignItems:"end"}}>
          <div>
            <label>جستجو</label>
            <input className="input" value={filters.q} onChange={(e)=>update("q", e.target.value)} placeholder="مثلاً: النگو / زنجیر / شمش ..." />
          </div>
          <div>
            <label>دسته‌بندی</label>
            <select className="input" value={filters.category} onChange={(e)=>update("category", e.target.value)}>
              {cats.map(c => <option key={c} value={c}>{c || "همه"}</option>)}
            </select>
          </div>
          <div>
            <label>حداقل قیمت (تومان)</label>
            <input className="input" value={filters.minPrice} onChange={(e)=>update("minPrice", e.target.value)} />
          </div>
          <div>
            <label>حداکثر قیمت (تومان)</label>
            <input className="input" value={filters.maxPrice} onChange={(e)=>update("maxPrice", e.target.value)} />
          </div>
        </div>

        <div className="grid" style={{gridTemplateColumns:"1fr 1fr 1fr 1fr", marginTop:10}}>
          <div>
            <label>حداقل وزن (گرم)</label>
            <input className="input" value={filters.minWeight} onChange={(e)=>update("minWeight", e.target.value)} />
          </div>
          <div>
            <label>حداکثر وزن (گرم)</label>
            <input className="input" value={filters.maxWeight} onChange={(e)=>update("maxWeight", e.target.value)} />
          </div>
          <div>
            <label>&nbsp;</label>
            <button className="btn" onClick={()=> setSp(new URLSearchParams(), { replace:true })}>پاک کردن فیلترها</button>
          </div>
          <div className="small" style={{alignSelf:"center"}}>
            {loading ? "در حال دریافت..." : `${items.length.toLocaleString("fa-IR")} محصول`}
          </div>
        </div>
      </div>

      <div className="productGrid" style={{marginTop:12}}>
        {items.map(p => (
          <Link key={p.id} to={`/product/${p.id}`} className="card productCard">
            <img src={p.image_url || "https://picsum.photos/seed/vintala/600/600"} alt={p.name}/>
            <div style={{marginTop:10, fontWeight:800}}>{p.name}</div>
            <div className="small">{p.category} • وزن {gram(p.weight_g)} گرم</div>
            <div className="kv" style={{marginTop:8}}>
              <div className="badge">قیمت: <b style={{color:"var(--accent)"}}>{money(p.price_toman)}</b></div>
              <span className="small">→</span>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}

import React, { useEffect, useState } from "react";
import { api, money, gram } from "../lib/api.js";
import { useAuth } from "../lib/auth.jsx";
import { useRealtime } from "../lib/realtime.jsx";

const cats = ["گوشواره","النگو","انگشتر","گردنبند","دستبند","سرویس","زنجیر","آویز","سکه","شمش","پک سرمایه‌گذاری"];

export default function AdminProducts(){
  const { user } = useAuth();
  const rt = useRealtime();
  const [items, setItems] = useState([]);
  const [gold, setGold] = useState(0);
  const [form, setForm] = useState({ name:"", category:"گوشواره", weight_g: 2.5, labor_pct: 8, image_url:"", description:"" });

  async function load(){
    const r = await api.get("/products?active=1");
    setItems(r.data.items || []);
    setGold(r.data.gold_price_per_g || 0);
  }
  useEffect(()=>{ load(); }, []);

  async function create(){
    await api.post("/products", { ...form, weight_g: Number(form.weight_g), labor_pct: Number(form.labor_pct) });
    rt?.pushToast?.("محصول", "محصول جدید ایجاد شد.");
    setForm({ name:"", category:"گوشواره", weight_g: 2.5, labor_pct: 8, image_url:"", description:"" });
    load();
  }

  async function disable(id){
    await api.delete(`/products/${id}`);
    rt?.pushToast?.("محصول", "محصول غیرفعال شد.");
    load();
  }

  if (!user || !["admin","seller"].includes(user.role)) {
    return <div className="card">دسترسی ندارید.</div>;
  }

  return (
    <div className="grid" style={{gridTemplateColumns:"0.9fr 1.1fr", gap:12}}>
      <div className="card">
        <h2 style={{margin:"6px 0"}}>مدیریت محصولات</h2>
        <div className="small">فروشنده می‌تواند اضافه/حذف (غیرفعال) کند. ادمین هم به همه دسترسی دارد.</div>
        <hr />
        <h4 style={{margin:"6px 0"}}>افزودن محصول</h4>
        <label>نام</label>
        <input className="input" value={form.name} onChange={(e)=>setForm({...form, name:e.target.value})} />
        <div style={{height:10}} />
        <label>دسته‌بندی</label>
        <select className="input" value={form.category} onChange={(e)=>setForm({...form, category:e.target.value})}>
          {cats.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
        <div style={{height:10}} />
        <div className="grid" style={{gridTemplateColumns:"1fr 1fr", gap:10}}>
          <div>
            <label>وزن (گرم)</label>
            <input className="input" value={form.weight_g} onChange={(e)=>setForm({...form, weight_g:e.target.value})} />
          </div>
          <div>
            <label>اجرت (%)</label>
            <input className="input" value={form.labor_pct} onChange={(e)=>setForm({...form, labor_pct:e.target.value})} />
          </div>
        </div>
        <div style={{height:10}} />
        <label>تصویر (URL)</label>
        <input className="input" value={form.image_url} onChange={(e)=>setForm({...form, image_url:e.target.value})} placeholder="اختیاری" />
        <div style={{height:10}} />
        <label>توضیحات</label>
        <input className="input" value={form.description} onChange={(e)=>setForm({...form, description:e.target.value})} placeholder="اختیاری" />

        <div className="row" style={{marginTop:12}}>
          <button className="btn success" onClick={create} disabled={!form.name.trim()}>ایجاد</button>
        </div>
      </div>

      <div className="card">
        <div className="row" style={{justifyContent:"space-between", alignItems:"center"}}>
          <h3 style={{margin:"6px 0"}}>محصولات فعال</h3>
          <span className="badge">قیمت لحظه‌ای/گرم: <b style={{color:"var(--accent)"}}>{money(gold)}</b></span>
        </div>
        <hr />
        <div className="grid" style={{gap:10}}>
          {items.map(p => (
            <div key={p.id} className="card" style={{padding:12}}>
              <div className="row" style={{justifyContent:"space-between", alignItems:"center"}}>
                <b>{p.name}</b>
                <button className="btn danger" onClick={()=>disable(p.id)}>حذف/غیرفعال</button>
              </div>
              <div className="small">{p.category} • وزن {gram(p.weight_g)} گرم</div>
              <div className="badge">قیمت فعلی: <b style={{color:"var(--accent)"}}>{money(p.price_toman)}</b> تومان</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

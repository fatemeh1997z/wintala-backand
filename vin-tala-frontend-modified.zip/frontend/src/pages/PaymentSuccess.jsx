import React from "react";
import { Link, useSearchParams } from "react-router-dom";

export default function PaymentSuccess(){
  const [sp] = useSearchParams();
  const orderId = sp.get("order_id");
  return (
    <div className="card">
      <h2 style={{margin:"6px 0"}}>پرداخت موفق</h2>
      <div className="small">پرداخت شما با موفقیت ثبت شد.</div>
      {orderId ? <div className="badge" style={{marginTop:10}}>سفارش: <b>#{orderId}</b></div> : null}
      <div className="row" style={{marginTop:12}}>
        <Link className="btn primary" to="/orders">مشاهده سفارش‌ها و دانلود فاکتور</Link>
        <Link className="btn" to="/explore">بازگشت به اکسپلور</Link>
      </div>
    </div>
  );
}

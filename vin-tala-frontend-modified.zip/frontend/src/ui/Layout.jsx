import React, { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { api, money } from "../lib/api.js";

export default function Layout({ user, children }) {
  const loc = useLocation();
  const [gold, setGold] = useState({ price_per_g: 0, updated_at: "" });
  const [support, setSupport] = useState(import.meta.env.VITE_SUPPORT_WHATSAPP || "");

  useEffect(() => {
    let mounted = true;
    async function tick(){
      try{
        const r = await api.get("/gold/price");
        if (mounted) setGold(r.data);
      }catch{}
    }
    tick();
    const t = setInterval(tick, 5000);
    return ()=>{ mounted=false; clearInterval(t); };
  }, []);

  // support number is provided by backend .env; show placeholder if empty
  useEffect(() => {
    api.get("/health").then(()=>{}).catch(()=>{});
  }, []);

  return (
    <>
      <header className="header">
        <div className="nav">
          <Link to="/" className="logo">
            <div className="logoMark">W</div>
            <div className="logoText">
              <b>وین طلا</b>
              <span>از دل کارگاه تو دست تو</span>
            </div>
          </Link>

          <nav className="navLinks">
            <Link className="btn" to="/explore">اکسپلور</Link>
            <Link className="btn" to="/cart">سبد خرید من</Link>
            <Link className="btn" to="/orders">سفارش‌ها</Link>
            <Link className="btn" to="/profile">پروفایل</Link>
          </nav>
        </div>
        <div className="container" style={{paddingTop:0}}>
          <div className="row" style={{justifyContent:"space-between", alignItems:"center"}}>
            <div className="badge">قیمت لحظه‌ای طلا: <b style={{color:"var(--accent)"}}>{money(gold.price_per_g)}</b> تومان / گرم</div>
            <div className="small">آخرین بروزرسانی: {gold.updated_at ? new Date(gold.updated_at).toLocaleTimeString("fa-IR") : "—"}</div>
          </div>
        </div>
      </header>

      <main className="container">
        {children}
      </main>

      <a className="whatsapp" href={support ? `https://wa.me/${support}` : "https://wa.me/"} target="_blank" rel="noreferrer">
        پشتیبانی واتس‌اپی
      </a>

      <footer className="container small" style={{paddingBottom:28}}>
        <hr />
        <div className="row" style={{justifyContent:"space-between"}}>
          <div>وین طلا — پنجره ی واحد خرید و فروش طلا</div>
          <div className="row">
            <Link to="/licenses">مجوزها (اتحادیه/اینماد)</Link>
            <span>•</span>
            <Link to="/about">درباره ما</Link>
            <span>•</span>
            <Link to="/contact">تماس با ما</Link>
          </div>
        </div>
      </footer>
    </>
  );
}

import React, { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { api, money, gram } from "../lib/api.js";

const cats = ["گوشواره","النگو","انگشتر","گردنبند","دستبند","سرویس","زنجیر","آویز","سکه","شمش","پک سرمایه‌گذاری"];

export default function Home(){
  const [items, setItems] = useState([]);
  const [gold, setGold] = useState(0);

  useEffect(() => {
    api.get("/products?active=1").then(r => {
      setItems(r.data.items.slice(0, 9));
      setGold(r.data.gold_price_per_g || 0);
    }).catch(()=>{});
  }, []);

  const packs = useMemo(() => items.filter(p => p.category.includes("پک")), [items]);
  const featured = useMemo(() => items.filter(p => !p.category.includes("پک")).slice(0,6), [items]);

  return (
    <div>
      <section className="hero">
        <div className="card">
          <div className="row" style={{justifyContent:"space-between", alignItems:"center"}}>
            <div>
              <h1>وین طلا — پنجره ی واحد خرید و فروش طلا</h1>
              <p>از دل کارگاه تو دست تو • قیمت‌گذاری بر اساس <b>قیمت لحظه‌ای طلا</b> و وزن</p>
              <div className="row" style={{marginTop:10}}>
                <Link className="btn primary" to="/explore">شروع گشت‌وگذار در اکسپلور</Link>
                <Link className="btn" to="/savings">پس‌انداز طلا (کمترین مبلغ)</Link>
                <Link className="btn" to="/custom-build">سفارش ساخت طلای دلخواه</Link>
              </div>
              <div className="row" style={{marginTop:10}}>
                <span className="badge">💡 هرچه سریع‌تر پولتو به طلا تبدیل کن</span>
                <span className="badge">کارمزد ۲٪ هنگام خرید کسر می‌شود</span>
                <span className="badge">امکان دریافت حضوری یا پست کالا</span>
              </div>
            </div>

            <div className="card" style={{minWidth:260}}>
              <div className="small">قیمت لحظه‌ای هر گرم</div>
              <div style={{fontSize:28, fontWeight:900, color:"var(--accent)"}}>{money(gold)} تومان</div>
              <div className="small">قیمت‌ها به صورت خودکار بروز می‌شوند.</div>
            </div>
          </div>
        </div>
      </section>

      <section style={{marginTop:14}}>
        <div className="row" style={{justifyContent:"space-between", alignItems:"center"}}>
          <h3 style={{margin:"8px 0"}}>دسته‌بندی‌ها</h3>
          <Link to="/explore" className="small">مشاهده همه →</Link>
        </div>
        <div className="row">
          {cats.map(c => (
            <Link key={c} to={`/explore?category=${encodeURIComponent(c)}`} className="badge">{c}</Link>
          ))}
        </div>
      </section>

      <section style={{marginTop:14}}>
        <div className="row" style={{justifyContent:"space-between", alignItems:"center"}}>
          <h3 style={{margin:"8px 0"}}>محصولات منتخب</h3>
          <Link to="/explore" className="small">اکسپلور →</Link>
        </div>
        <div className="productGrid">
          {featured.map(p => <ProductCard key={p.id} p={p} />)}
        </div>
      </section>

      <section style={{marginTop:14}}>
        <div className="row" style={{justifyContent:"space-between", alignItems:"center"}}>
          <h3 style={{margin:"8px 0"}}>پک‌های سرمایه‌گذاری</h3>
          <Link to="/explore?category=%D9%BE%DA%A9%20%D8%B3%D8%B1%D9%85%D8%A7%DB%8C%D9%87%E2%80%8C%DA%AF%D8%B0%D8%A7%D8%B1%DB%8C" className="small">نمایش →</Link>
        </div>
        <div className="productGrid">
          {packs.map(p => <ProductCard key={p.id} p={p} />)}
        </div>
      </section>
    </div>
  );
}

function ProductCard({ p }){
  return (
    <Link to={`/product/${p.id}`} className="card productCard">
      <img src={p.image_url || "https://picsum.photos/seed/vintala/600/600"} alt={p.name}/>
      <div style={{marginTop:10, fontWeight:800}}>{p.name}</div>
      <div className="small">{p.category} • وزن {gram(p.weight_g)} گرم</div>
      <div className="kv" style={{marginTop:8}}>
        <div className="badge">قیمت: <b style={{color:"var(--accent)"}}>{money(p.price_toman)}</b></div>
        <span className="small">→</span>
      </div>
    </Link>
  );
}

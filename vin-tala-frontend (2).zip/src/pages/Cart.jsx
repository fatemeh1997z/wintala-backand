import React, { useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { api, money, gram } from "../lib/api.js";
import { useAuth } from "../lib/auth.jsx";
import { useRealtime } from "../lib/realtime.jsx";

export default function Cart(){
  const { user } = useAuth();
  const rt = useRealtime();
  const nav = useNavigate();

  const [data, setData] = useState(null);
  const [shipping, setShipping] = useState("pickup");
  const [address, setAddress] = useState("");
  const [note, setNote] = useState("");
  const [payGold, setPayGold] = useState(0);
  const [wallet, setWallet] = useState(null);

  async function load(){
    try{
      const r = await api.get("/cart");
      setData(r.data);
      const w = await api.get("/savings");
      setWallet(w.data.wallet);
    }catch(e){
      setData({ needLogin:true });
    }
  }

  useEffect(() => { load(); }, []);

  async function setQty(pid, qty){
    await api.patch(`/cart/items/${pid}`, { qty: Number(qty) });
    load();
  }
  async function remove(pid){
    await api.delete(`/cart/items/${pid}`);
    load();
  }

  async function checkout(){
    const r = await api.post("/orders/checkout", {
      shipping_method: shipping,
      shipping_address: shipping === "post" ? address : "",
      note,
      pay_with_savings_gold_g: Number(payGold) || 0
    });
    rt?.pushToast?.("ثبت سفارش", `سفارش #${r.data.order_id} ایجاد شد. انتقال به پرداخت...`);
    window.location.href = r.data.payment.payment_url;
  }

  if (!data) return <div className="card">در حال بارگذاری...</div>;
  if (data.needLogin) return (
    <div className="card">
      <b>برای مشاهده سبد خرید باید وارد شوید.</b>
      <div className="row" style={{marginTop:10}}>
        <Link className="btn primary" to="/profile">ورود / ثبت‌نام</Link>
      </div>
    </div>
  );

  const items = data.items || [];

  return (
    <div className="grid" style={{gridTemplateColumns:"1.15fr 0.85fr"}}>
      <div className="card">
        <h2 style={{margin:"6px 0"}}>سبد خرید من</h2>
        <div className="small">قیمت‌ها با توجه به قیمت لحظه‌ای طلا و وزن محاسبه می‌شود.</div>
        <hr />
        {items.length ? items.map(it => (
          <div key={it.product_id} className="card" style={{marginBottom:10}}>
            <div className="row" style={{justifyContent:"space-between", alignItems:"center"}}>
              <div>
                <b>{it.name}</b>
                <div className="small">{it.category} • وزن {gram(it.weight_g)} گرم</div>
                <div className="badge">قیمت واحد: <b style={{color:"var(--accent)"}}>{money(it.price_toman)}</b> تومان</div>
              </div>
              <div style={{minWidth:180}}>
                <label>تعداد</label>
                <input className="input" type="number" min="1" max="50" value={it.qty} onChange={(e)=>setQty(it.product_id, e.target.value)} />
                <div className="row" style={{marginTop:8}}>
                  <button className="btn danger" onClick={()=>remove(it.product_id)}>حذف</button>
                  <Link className="btn" to={`/product/${it.product_id}`}>مشاهده</Link>
                </div>
              </div>
            </div>
          </div>
        )) : <div className="small">سبد خرید خالی است.</div>}
      </div>

      <div className="card">
        <h3 style={{margin:"6px 0"}}>جمع‌بندی و ثبت سفارش</h3>
        <div className="badge">جمع جزء: <b>{money(data.subtotal)}</b> تومان</div>
        <div className="badge">کارمزد ۲٪ (کسر می‌شود): <b>{money(data.fee_amount)}</b> تومان</div>
        <div className="badge">مبلغ نهایی (قبل از پس‌انداز): <b style={{color:"var(--accent)"}}>{money(data.total)}</b> تومان</div>

        <hr />
        <div className="grid" style={{gap:10}}>
          <div>
            <label>روش دریافت</label>
            <select className="input" value={shipping} onChange={(e)=>setShipping(e.target.value)}>
              <option value="pickup">دریافت حضوری</option>
              <option value="post">پست کالا</option>
            </select>
          </div>
          {shipping === "post" ? (
            <div>
              <label>آدرس پستی</label>
              <textarea className="input" rows="3" value={address} onChange={(e)=>setAddress(e.target.value)} />
            </div>
          ) : null}
          <div>
            <label>یادداشت (اختیاری)</label>
            <input className="input" value={note} onChange={(e)=>setNote(e.target.value)} placeholder="مثلاً: ساعت مراجعه / توضیحات..." />
          </div>

          <div>
            <label>پرداخت با طلای پس‌انداز شده (گرم)</label>
            <input className="input" value={payGold} onChange={(e)=>setPayGold(e.target.value)} />
            <div className="small" style={{marginTop:6}}>
              موجودی پس‌انداز: <b>{(wallet?.gold_g || 0).toLocaleString("fa-IR", {maximumFractionDigits:4})}</b> گرم
            </div>
          </div>

          <button className="btn success" disabled={!items.length} onClick={checkout}>
            پرداخت امن و ثبت نهایی
          </button>
          <div className="small">
            پس از پرداخت، فاکتور رسمی با ضمانت از صفحه سفارش‌ها قابل دریافت است.
          </div>
        </div>
      </div>
    </div>
  );
}

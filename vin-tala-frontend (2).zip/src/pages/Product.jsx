import React, { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { api, money, gram } from "../lib/api.js";
import { useAuth } from "../lib/auth.jsx";
import { useRealtime } from "../lib/realtime.jsx";

export default function Product(){
  const { id } = useParams();
  const { user } = useAuth();
  const rt = useRealtime();
  const [data, setData] = useState(null);
  const [qty, setQty] = useState(1);

  const [rating, setRating] = useState(5);
  const [text, setText] = useState("");

  useEffect(() => {
    api.get(`/products/${id}`).then(r => setData(r.data)).catch(()=> setData({ error:true }));
  }, [id]);

  const p = data?.item;

  async function addToCart(){
    await api.post("/cart/items", { product_id: Number(id), qty: Number(qty) || 1 });
    rt?.pushToast?.("سبد خرید", "به سبد خرید اضافه شد.");
  }

  async function submitReview(){
    await api.post("/reviews", { product_id: Number(id), rating: Number(rating), text });
    setText("");
    rt?.pushToast?.("نظر ثبت شد", "ممنون از بازخورد شما.");
    const r = await api.get(`/products/${id}`);
    setData(r.data);
  }

  if (!data) return <div className="card">در حال بارگذاری...</div>;
  if (data.error) return <div className="card">محصول پیدا نشد.</div>;

  return (
    <div className="grid" style={{gridTemplateColumns:"1.1fr 0.9fr", gap:12}}>
      <div className="card">
        <img src={p.image_url || "https://picsum.photos/seed/vintala/600/600"} alt={p.name} style={{width:"100%", borderRadius:16, border:"1px solid var(--border)"}} />
        <h2 style={{margin:"12px 0 6px"}}>{p.name}</h2>
        <div className="row">
          <span className="badge">{p.category}</span>
          <span className="badge">وزن: {gram(p.weight_g)} گرم</span>
          <span className="badge">قیمت لحظه‌ای/گرم: {money(data.gold_price_per_g)} تومان</span>
        </div>
        <p className="small" style={{marginTop:10}}>{p.description || "—"}</p>

        <hr />
        <h3 style={{margin:"6px 0"}}>نظرات</h3>
        <div className="small" style={{marginBottom:8}}>
          {data.demo_mode ? "دیدگاه‌های «نمونه (دمو)» صرفاً برای نمایش در حالت دمو هستند و با برچسب مشخص می‌شوند." : null}
        </div>
        <div className="grid" style={{gap:8}}>
          {data.reviews?.length ? data.reviews.map(rv => (
            <div key={rv.id} className="card" style={{padding:12}}>
              <div className="row" style={{justifyContent:"space-between", alignItems:"center"}}>
                <div>⭐ {rv.rating}</div>
                {rv.is_sample ? <span className="badge">نمونه (دمو)</span> : <span className="small">{new Date(rv.created_at).toLocaleDateString("fa-IR")}</span>}
              </div>
              <div style={{marginTop:6}}>{rv.text}</div>
            </div>
          )) : <div className="small">هنوز نظری ثبت نشده.</div>}
        </div>

        {user ? (
          <div className="card" style={{marginTop:12}}>
            <h4 style={{margin:"0 0 8px"}}>ثبت نظر</h4>
            <div className="grid" style={{gridTemplateColumns:"120px 1fr", gap:10}}>
              <div>
                <label>امتیاز</label>
                <select className="input" value={rating} onChange={(e)=>setRating(e.target.value)}>
                  {[5,4,3,2,1].map(x => <option key={x} value={x}>{x}</option>)}
                </select>
              </div>
              <div>
                <label>متن نظر</label>
                <input className="input" value={text} onChange={(e)=>setText(e.target.value)} placeholder="نظر شما..." />
              </div>
            </div>
            <div style={{marginTop:10}}>
              <button className="btn primary" onClick={submitReview} disabled={!text.trim()}>ثبت</button>
            </div>
          </div>
        ) : (
          <div className="small" style={{marginTop:10}}>
            برای ثبت نظر، <Link to="/profile" style={{textDecoration:"underline"}}>وارد شوید</Link>.
          </div>
        )}
      </div>

      <div className="card">
        <div className="badge">قیمت محصول: <b style={{color:"var(--accent)"}}>{money(p.price_toman)}</b> تومان</div>
        <div className="small" style={{marginTop:8}}>
          کارمزد ۲٪ هنگام خرید کسر می‌شود (در جمع نهایی سبد).
        </div>

        <div className="grid" style={{gridTemplateColumns:"1fr 1fr", gap:10, marginTop:12}}>
          <div>
            <label>تعداد</label>
            <input className="input" type="number" min="1" max="50" value={qty} onChange={(e)=>setQty(e.target.value)} />
          </div>
          <div>
            <label>قیمت تقریبی</label>
            <div className="input" style={{display:"flex", alignItems:"center"}}>{money((Number(qty)||1) * p.price_toman)} تومان</div>
          </div>
        </div>

        <div className="row" style={{marginTop:12}}>
          <button className="btn success" onClick={addToCart}>افزودن به سبد</button>
          <Link className="btn" to="/cart">رفتن به سبد</Link>
        </div>

        <hr />
        <div className="small">
          روش‌های دریافت: <b>حضوری</b> یا <b>پست</b> در مرحله ثبت سفارش.
        </div>
        <div className="small" style={{marginTop:6}}>
          فاکتور رسمی با ضمانت پس از پرداخت قابل دانلود است.
        </div>
      </div>
    </div>
  );
}

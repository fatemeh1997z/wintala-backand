import React from "react";

export default function StaticPage({ kind }){
  const content = {
    about: {
      title: "درباره ما",
      body: "وین طلا بستری برای خرید و فروش طلا با قیمت‌گذاری لحظه‌ای و شفاف است. شعار ما: از دل کارگاه تو دست تو."
    },
    contact: {
      title: "تماس با ما",
      body: "برای ارتباط، از دکمه پشتیبانی واتس‌اپ در پایین صفحه استفاده کنید یا اطلاعات تماس خود را اینجا قرار دهید."
    },
    licenses: {
      title: "مجوزها",
      body: "در این بخش می‌توانید مجوز اتحادیه طلا، اینماد و سایر مدارک را درج کنید (در نسخه MVP صرفاً جایگزین/placeholder)."
    }
  }[kind] || { title: "صفحه", body: "" };

  return (
    <div className="card">
      <h2 style={{margin:"6px 0"}}>{content.title}</h2>
      <hr />
      <p className="small">{content.body}</p>
      <div className="small">* در نسخه واقعی، محتوای حقوقی/اعتمادسازی باید دقیق و مطابق قوانین تنظیم شود.</div>
    </div>
  );
}

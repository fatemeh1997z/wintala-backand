import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../lib/auth.jsx";

export default function Profile(){
  const { user, login, register, logout } = useAuth();
  const nav = useNavigate();

  const [mode, setMode] = useState("login");
  const [role, setRole] = useState("buyer");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("buyer@vintala.local");
  const [password, setPassword] = useState("Buyer123!");
  const [err, setErr] = useState("");

  async function submit(){
    setErr("");
    try{
      if (mode === "login") {
        await login(email, password);
        nav("/");
      } else {
        await register(role, name || "کاربر جدید", email, phone, password);
        nav("/");
      }
    }catch(e){
      setErr("خطا در ورود/ثبت‌نام. اطلاعات را بررسی کنید.");
    }
  }

  if (user) {
    return (
      <div className="card">
        <h2 style={{margin:"6px 0"}}>پروفایل</h2>
        <div className="row">
          <span className="badge">نام: <b>{user.name}</b></span>
          <span className="badge">نقش: <b>{user.role}</b></span>
        </div>
        <div className="row" style={{marginTop:10}}>
          <Link className="btn" to="/orders">سابقه سفارش‌ها</Link>
          <Link className="btn" to="/savings">پس‌انداز طلا</Link>
          <Link className="btn" to="/custom-build">درخواست ساخت</Link>
          {(user.role === "admin" || user.role === "seller") ? <Link className="btn primary" to="/admin/products">مدیریت محصولات</Link> : null}
          <button className="btn danger" onClick={logout}>خروج</button>
        </div>
        <div className="small" style={{marginTop:12}}>
          منوی اصلی شامل: پروفایل، سبد خرید من، دسته‌بندی‌ها/اکسپلور و سفارش‌ها است.
        </div>
      </div>
    );
  }

  return (
    <div className="grid" style={{gridTemplateColumns:"1fr 1fr", gap:12}}>
      <div className="card">
        <h2 style={{margin:"6px 0"}}>ورود</h2>
        <div className="small">برای تست سریع می‌توانید از حساب‌های seed استفاده کنید.</div>
        <hr />
        <label>ایمیل</label>
        <input className="input" value={email} onChange={(e)=>setEmail(e.target.value)} />
        <div style={{height:10}} />
        <label>رمز عبور</label>
        <input className="input" type="password" value={password} onChange={(e)=>setPassword(e.target.value)} />
        {err ? <div className="small" style={{color:"var(--danger)", marginTop:8}}>{err}</div> : null}
        <div className="row" style={{marginTop:12}}>
          <button className="btn success" onClick={()=>{ setMode("login"); submit(); }}>ورود</button>
          <button className="btn" onClick={()=>{ setEmail("seller@vintala.local"); setPassword("Seller123!"); }}>حساب فروشنده</button>
          <button className="btn" onClick={()=>{ setEmail("admin@vintala.local"); setPassword("Admin123!"); }}>حساب ادمین</button>
        </div>
      </div>

      <div className="card">
        <h2 style={{margin:"6px 0"}}>ثبت‌نام</h2>
        <hr />
        <label>نقش</label>
        <select className="input" value={role} onChange={(e)=>setRole(e.target.value)}>
          <option value="buyer">خریدار</option>
          <option value="seller">فروشنده</option>
        </select>
        <div style={{height:10}} />
        <label>نام</label>
        <input className="input" value={name} onChange={(e)=>setName(e.target.value)} />
        <div style={{height:10}} />
        <label>تلفن (اختیاری)</label>
        <input className="input" value={phone} onChange={(e)=>setPhone(e.target.value)} />
        <div style={{height:10}} />
        <label>ایمیل</label>
        <input className="input" value={email} onChange={(e)=>setEmail(e.target.value)} />
        <div style={{height:10}} />
        <label>رمز عبور (حداقل ۸ کاراکتر)</label>
        <input className="input" type="password" value={password} onChange={(e)=>setPassword(e.target.value)} />

        <div className="row" style={{marginTop:12}}>
          <button className="btn primary" onClick={()=>{ setMode("register"); submit(); }}>ساخت حساب</button>
        </div>
        <div className="small" style={{marginTop:10}}>
          با ثبت‌نام شما می‌توانید خرید کنید، سفارش‌ها را ببینید و در صورت فروشنده بودن محصول اضافه/حذف کنید.
        </div>
      </div>
    </div>
  );
}

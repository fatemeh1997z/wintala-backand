# VinTala Frontend (React + Vite)

## Run
```bash
cd frontend
cp .env.example .env
npm install
npm run dev
```

Default backend: `http://localhost:4000`

## Seeded accounts
See backend README.

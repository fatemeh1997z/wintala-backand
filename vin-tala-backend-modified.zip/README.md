# VinTala Backend (Express + SQLite)

## Run (local)
```bash
cd backend
cp .env.example .env
npm install
npm run seed
npm run dev
```

- API base: `http://localhost:4000/api`
- Socket.IO: `http://localhost:4000`

## Roles
- buyer
- seller
- admin

Seeded users:
- Admin: `admin@vintala.local` / `Admin123!`
- Seller: `seller@vintala.local` / `Seller123!`
- Buyer: `buyer@vintala.local` / `Buyer123!`

> **Note about reviews**: The seed inserts **sample/demo reviews** (flagged as `is_sample=true`) and the UI labels them as "نمونه (دمو)" when `DEMO_MODE=true`.

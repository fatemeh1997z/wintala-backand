export function getPaymentProvider() {
  return (process.env.PAYMENT_PROVIDER || "mock").toLowerCase();
}

export function getPublicBaseUrl(req) {
  return process.env.PUBLIC_BASE_URL || `${req.protocol}://${req.get("host")}`;
}

// Mock provider: redirects to a hosted page on backend to simulate payment.
export async function startPayment({ orderId, amountToman, req }) {
  const provider = getPaymentProvider();
  const base = getPublicBaseUrl(req);

  if (provider === "mock") {
    return { provider, payment_url: `${base}/pay/mock/${orderId}` };
  }

  // NOTE: Secure payment gateways need merchant credentials + callback verification.
  // This project includes only a safe scaffold; integrate your real provider here.
  return { provider, payment_url: `${base}/pay/mock/${orderId}` };
}

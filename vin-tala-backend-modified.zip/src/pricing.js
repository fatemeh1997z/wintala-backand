export function computeProductPriceToman({ weight_g, labor_pct }, gold_price_per_g) {
  const w = Number(weight_g) || 0;
  const labor = Number(labor_pct) || 0;
  const base = w * gold_price_per_g;
  const withLabor = base * (1 + labor / 100);
  return Math.round(withLabor);
}

export function computeCartTotalsToman(subtotal, feeMode = "buyer_discount") {
  // Requirement: "کم کردن 2 درصد کارمزد هنگام خرید"
  // Default: buyer pays 2% less (a discount), but fee_amount is still recorded.
  const s = Math.max(0, Math.round(subtotal));
  const fee = Math.round(s * 0.02);
  if (feeMode === "buyer_discount") {
    return { subtotal: s, fee_amount: fee, total: Math.max(0, s - fee) };
  }
  // Alternative: fee is additional
  if (feeMode === "buyer_fee") {
    return { subtotal: s, fee_amount: fee, total: s + fee };
  }
  // Seller commission: buyer pays subtotal, seller receives subtotal - fee
  if (feeMode === "seller_commission") {
    return { subtotal: s, fee_amount: fee, total: s };
  }
  return { subtotal: s, fee_amount: fee, total: Math.max(0, s - fee) };
}

import fetch from "node-fetch";

function parseNumber(x) {
  const n = Number(x);
  return Number.isFinite(n) ? n : null;
}

export class GoldPriceService {
  constructor({ db, io }) {
    this.db = db;
    this.io = io;
    this.current = { price_per_g: 0, source: "init", updated_at: new Date().toISOString() };
    this.lastNotifiedPrice = null;
  }

  async start() {
    await this.refresh(true);
    const poll = parseInt(process.env.GOLD_POLL_SECONDS || "30", 10);
    setInterval(() => this.refresh(false).catch(() => {}), Math.max(5, poll) * 1000);
  }

  async refresh(initial) {
    const source = (process.env.GOLD_PRICE_SOURCE || "mock").toLowerCase();
    let price = null;

    if (source === "provider") {
      // Generic provider: expected to return JSON with { price_per_g } or similar.
      // You can adapt this to your provider format.
      const url = process.env.GOLD_API_URL;
      const key = process.env.GOLD_API_KEY;
      if (url) {
        const res = await fetch(url, { headers: key ? { "Authorization": `Bearer ${key}` } : {} });
        const data = await res.json();
        price =
          parseNumber(data?.price_per_g) ??
          parseNumber(data?.pricePerGram) ??
          parseNumber(data?.gold?.price_per_g) ??
          null;
      }
    }

    if (price == null) {
      // Mock: random walk around a base (per gram in toman)
      const base = this.current.price_per_g || 3500000; // default 3,500,000 toman per gram
      const delta = (Math.random() - 0.5) * 25000; // +-12,500 toman
      price = Math.max(500000, Math.round(base + delta));
    }

    const prev = this.current.price_per_g;
    this.current = { price_per_g: price, source, updated_at: new Date().toISOString() };
    await this.db.run("INSERT INTO gold_price_history(price_per_g) VALUES (?)", price);

    this.io?.emit("gold:price", this.current);

    // Notify users if price increased enough (buyer-focused message)
    const alertPercent = parseFloat(process.env.GOLD_ALERT_PERCENT || "0.5");
    if (!initial && prev > 0) {
      const pct = ((price - prev) / prev) * 100;
      if (pct >= alertPercent) {
        await this.notifyPriceUp(pct, price, prev);
      }
    }
  }

  async notifyPriceUp(pct, price, prev) {
    // Throttle: don't notify again unless price meaningfully changes
    if (this.lastNotifiedPrice && Math.abs(price - this.lastNotifiedPrice) < prev * 0.003) return;
    this.lastNotifiedPrice = price;

    const title = "افزایش قیمت طلا";
    const body = `قیمت لحظه‌ای طلا حدود ${pct.toFixed(2)}٪ افزایش یافت. هرچه سریع‌تر پولتو به طلا تبدیل کن.`;

    const buyers = await this.db.all("SELECT id FROM users WHERE role IN ('buyer','seller','admin')");
    for (const u of buyers) {
      await this.db.run(
        "INSERT INTO notifications(user_id, title, body) VALUES (?,?,?)",
        u.id, title, body
      );
      this.io?.to(`user:${u.id}`)?.emit("notify", { title, body });
    }
  }

  get() {
    return this.current;
  }
}

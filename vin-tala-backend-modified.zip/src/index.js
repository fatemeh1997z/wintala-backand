import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import morgan from "morgan";
import rateLimit from "express-rate-limit";
import http from "http";
import { Server } from "socket.io";
import { z } from "zod";

import { openDb, initDb } from "./db.js";
import { authRequired, requireRole, signToken, hashPassword, verifyPassword } from "./auth.js";
import { GoldPriceService } from "./gold.js";
import { computeProductPriceToman, computeCartTotalsToman } from "./pricing.js";
import { startPayment } from "./payment.js";

import PDFDocument from "pdfkit";

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: process.env.CORS_ORIGIN || true, credentials: true } });

app.use(helmet());
app.use(cors({ origin: process.env.CORS_ORIGIN || true, credentials: true }));
app.use(express.json({ limit: "1mb" }));
app.use(morgan("dev"));
app.use(rateLimit({ windowMs: 60_000, max: 120 }));

let db;
let gold;

function formatPersianDate(iso) {
  return new Date(iso).toLocaleString("fa-IR");
}

io.on("connection", (socket) => {
  socket.on("auth", (token) => {
    try {
      const jwt = token?.startsWith("Bearer ") ? token.slice(7) : token;
      const payload = JSON.parse(Buffer.from(jwt.split(".")[1], "base64").toString("utf8"));
      // NOTE: This is lightweight room join; server-side auth is still enforced on REST endpoints.
      if (payload?.id) socket.join(`user:${payload.id}`);
    } catch {}
  });
});

function requireDemoSafe(req, res, next) {
  // Reviews are real user-generated; seed inserts "sample" only in demo mode, labeled in UI.
  next();
}

app.get("/api/health", (req, res) => res.json({ ok: true }));

// --- Auth ---
const registerSchema = z.object({
  role: z.enum(["buyer", "seller"]),
  name: z.string().min(2),
  email: z.string().email(),
  phone: z.string().optional(),
  password: z.string().min(8)
});

app.post("/api/auth/register", async (req, res) => {
  const parsed = registerSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "BAD_REQUEST", details: parsed.error.flatten() });

  const { role, name, email, phone, password } = parsed.data;
  const password_hash = await hashPassword(password);

  try {
    const result = await db.run(
      "INSERT INTO users(role,name,email,phone,password_hash) VALUES (?,?,?,?,?)",
      role, name, email.toLowerCase(), phone || null, password_hash
    );
    const user = { id: result.lastID, role, name, email };
    await db.run("INSERT OR IGNORE INTO carts(user_id) VALUES (?)", user.id);
    await db.run("INSERT OR IGNORE INTO savings_wallets(user_id) VALUES (?)", user.id);
    return res.json({ token: signToken(user), user });
  } catch (e) {
    return res.status(409).json({ error: "EMAIL_EXISTS" });
  }
});

const loginSchema = z.object({ email: z.string().email(), password: z.string().min(1) });

app.post("/api/auth/login", async (req, res) => {
  const parsed = loginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "BAD_REQUEST" });

  const { email, password } = parsed.data;
  const user = await db.get("SELECT id, role, name, email, password_hash FROM users WHERE email = ?", email.toLowerCase());
  if (!user) return res.status(401).json({ error: "INVALID_CREDENTIALS" });
  const ok = await verifyPassword(password, user.password_hash);
  if (!ok) return res.status(401).json({ error: "INVALID_CREDENTIALS" });

  await db.run("INSERT OR IGNORE INTO carts(user_id) VALUES (?)", user.id);
  await db.run("INSERT OR IGNORE INTO savings_wallets(user_id) VALUES (?)", user.id);

  const safeUser = { id: user.id, role: user.role, name: user.name, email: user.email };
  res.json({ token: signToken(safeUser), user: safeUser });
});

app.get("/api/me", authRequired, async (req, res) => {
  const user = await db.get("SELECT id, role, name, phone, email, created_at FROM users WHERE id = ?", req.user.id);
  res.json({ user });
});

// --- Gold price ---
app.get("/api/gold/price", (req, res) => res.json(gold.get()));

// --- Products ---
app.get("/api/products", async (req, res) => {
  const { q, category, minPrice, maxPrice, minWeight, maxWeight, active } = req.query;
  const goldPrice = gold.get().price_per_g;

  const where = [];
  const params = [];
  if (q) { where.push("(name LIKE ? OR description LIKE ?)"); params.push(`%${q}%`, `%${q}%`); }
  if (category) { where.push("category = ?"); params.push(category); }
  if (active !== undefined) { where.push("active = ?"); params.push(active === "0" ? 0 : 1); }

  const sql = `SELECT * FROM products ${where.length ? "WHERE " + where.join(" AND ") : ""} ORDER BY id DESC`;
  const items = await db.all(sql, ...params);

  const enriched = items.map(p => {
    const price = computeProductPriceToman(p, goldPrice);
    return { ...p, price_toman: price };
  }).filter(p => {
    const price = p.price_toman;
    const w = Number(p.weight_g);
    if (minPrice && price < Number(minPrice)) return false;
    if (maxPrice && price > Number(maxPrice)) return false;
    if (minWeight && w < Number(minWeight)) return false;
    if (maxWeight && w > Number(maxWeight)) return false;
    return true;
  });

  res.json({ items: enriched, gold_price_per_g: goldPrice });
});

app.get("/api/products/:id", async (req, res) => {
  const id = Number(req.params.id);
  const p = await db.get("SELECT * FROM products WHERE id = ?", id);
  if (!p) return res.status(404).json({ error: "NOT_FOUND" });
  const goldPrice = gold.get().price_per_g;
  const price = computeProductPriceToman(p, goldPrice);
  const reviews = await db.all("SELECT id, rating, text, is_sample, created_at FROM reviews WHERE product_id = ? ORDER BY id DESC", id);
  res.json({ item: { ...p, price_toman: price }, reviews, gold_price_per_g: goldPrice, demo_mode: (process.env.DEMO_MODE || "true") === "true" });
});

const productSchema = z.object({
  name: z.string().min(2),
  category: z.string().min(2),
  weight_g: z.number().positive(),
  labor_pct: z.number().min(0).max(50).default(7),
  image_url: z.string().url().optional(),
  description: z.string().optional(),
  active: z.boolean().optional()
});

app.post("/api/products", authRequired, requireRole("seller","admin"), async (req, res) => {
  const parsed = productSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "BAD_REQUEST", details: parsed.error.flatten() });

  const seller_id = req.user.role === "seller" ? req.user.id : (req.body.seller_id || null);
  const { name, category, weight_g, labor_pct, image_url, description } = parsed.data;

  const result = await db.run(
    "INSERT INTO products(seller_id,name,category,weight_g,labor_pct,image_url,description,active) VALUES (?,?,?,?,?,?,?,1)",
    seller_id, name, category, weight_g, labor_pct, image_url || null, description || null
  );
  res.json({ id: result.lastID });
});

app.put("/api/products/:id", authRequired, requireRole("seller","admin"), async (req, res) => {
  const id = Number(req.params.id);
  const existing = await db.get("SELECT * FROM products WHERE id = ?", id);
  if (!existing) return res.status(404).json({ error: "NOT_FOUND" });
  if (req.user.role === "seller" && existing.seller_id !== req.user.id) return res.status(403).json({ error: "FORBIDDEN" });

  const parsed = productSchema.partial().safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "BAD_REQUEST", details: parsed.error.flatten() });

  const updates = parsed.data;
  const fields = [];
  const params = [];
  for (const [k, v] of Object.entries(updates)) {
    fields.push(`${k} = ?`);
    params.push(v);
  }
  if (!fields.length) return res.json({ ok: true });
  params.push(id);

  await db.run(`UPDATE products SET ${fields.join(", ")} WHERE id = ?`, ...params);
  res.json({ ok: true });
});

app.delete("/api/products/:id", authRequired, requireRole("seller","admin"), async (req, res) => {
  const id = Number(req.params.id);
  const existing = await db.get("SELECT * FROM products WHERE id = ?", id);
  if (!existing) return res.status(404).json({ error: "NOT_FOUND" });
  if (req.user.role === "seller" && existing.seller_id !== req.user.id) return res.status(403).json({ error: "FORBIDDEN" });

  await db.run("UPDATE products SET active = 0 WHERE id = ?", id);
  res.json({ ok: true });
});

// --- Reviews (real UGC + demo sample seed) ---
const reviewSchema = z.object({
  product_id: z.number().int().positive(),
  rating: z.number().int().min(1).max(5),
  text: z.string().min(2).max(800)
});

app.post("/api/reviews", authRequired, requireDemoSafe, async (req, res) => {
  const parsed = reviewSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "BAD_REQUEST", details: parsed.error.flatten() });

  const { product_id, rating, text } = parsed.data;
  const exists = await db.get("SELECT id FROM products WHERE id = ? AND active = 1", product_id);
  if (!exists) return res.status(404).json({ error: "NOT_FOUND" });

  await db.run(
    "INSERT INTO reviews(product_id,user_id,rating,text,is_sample) VALUES (?,?,?,?,0)",
    product_id, req.user.id, rating, text
  );
  res.json({ ok: true });
});

// --- Cart ---
async function ensureCart(userId) {
  await db.run("INSERT OR IGNORE INTO carts(user_id) VALUES (?)", userId);
  return db.get("SELECT id FROM carts WHERE user_id = ?", userId);
}

app.get("/api/cart", authRequired, async (req, res) => {
  const cart = await ensureCart(req.user.id);
  const rows = await db.all(`
    SELECT ci.product_id, ci.qty, p.name, p.category, p.weight_g, p.labor_pct, p.image_url, p.seller_id
    FROM cart_items ci
    JOIN products p ON p.id = ci.product_id
    WHERE ci.cart_id = ?
  `, cart.id);

  const goldPrice = gold.get().price_per_g;
  const items = rows.map(r => ({ ...r, price_toman: computeProductPriceToman(r, goldPrice) }));
  const subtotal = items.reduce((sum, it) => sum + it.price_toman * it.qty, 0);
  const totals = computeCartTotalsToman(subtotal, process.env.FEE_MODE || "buyer_discount");

  res.json({ items, gold_price_per_g: goldPrice, ...totals });
});

const addToCartSchema = z.object({ product_id: z.number().int().positive(), qty: z.number().int().min(1).max(50).default(1) });

app.post("/api/cart/items", authRequired, async (req, res) => {
  const parsed = addToCartSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "BAD_REQUEST" });

  const cart = await ensureCart(req.user.id);
  const { product_id, qty } = parsed.data;

  const p = await db.get("SELECT id, active FROM products WHERE id = ?", product_id);
  if (!p || p.active !== 1) return res.status(404).json({ error: "NOT_FOUND" });

  await db.run(
    "INSERT INTO cart_items(cart_id,product_id,qty) VALUES (?,?,?) ON CONFLICT(cart_id,product_id) DO UPDATE SET qty = qty + excluded.qty",
    cart.id, product_id, qty
  );
  res.json({ ok: true });
});

const updateQtySchema = z.object({ qty: z.number().int().min(1).max(50) });

app.patch("/api/cart/items/:productId", authRequired, async (req, res) => {
  const parsed = updateQtySchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "BAD_REQUEST" });

  const cart = await ensureCart(req.user.id);
  const pid = Number(req.params.productId);
  await db.run("UPDATE cart_items SET qty = ? WHERE cart_id = ? AND product_id = ?", parsed.data.qty, cart.id, pid);
  res.json({ ok: true });
});

app.delete("/api/cart/items/:productId", authRequired, async (req, res) => {
  const cart = await ensureCart(req.user.id);
  const pid = Number(req.params.productId);
  await db.run("DELETE FROM cart_items WHERE cart_id = ? AND product_id = ?", cart.id, pid);
  res.json({ ok: true });
});

// --- Savings wallet (gold saving) ---
app.get("/api/savings", authRequired, async (req, res) => {
  await db.run("INSERT OR IGNORE INTO savings_wallets(user_id) VALUES (?)", req.user.id);
  const wallet = await db.get("SELECT * FROM savings_wallets WHERE user_id = ?", req.user.id);
  res.json({ wallet, gold_price_per_g: gold.get().price_per_g });
});

const buyGoldSchema = z.object({ amount_toman: z.number().positive() });

app.post("/api/savings/buy", authRequired, async (req, res) => {
  const parsed = buyGoldSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "BAD_REQUEST" });

  const amount = parsed.data.amount_toman;
  const price = gold.get().price_per_g;
  const gold_g = amount / price;

  const w = await db.get("SELECT gold_g, avg_cost_per_g FROM savings_wallets WHERE user_id = ?", req.user.id);
  const oldGold = Number(w?.gold_g || 0);
  const oldAvg = Number(w?.avg_cost_per_g || 0);
  const oldCost = oldGold * oldAvg;
  const newGold = oldGold + gold_g;
  const newAvg = newGold > 0 ? (oldCost + amount) / newGold : 0;

  await db.run("INSERT OR IGNORE INTO savings_wallets(user_id) VALUES (?)", req.user.id);
  await db.run(
    "UPDATE savings_wallets SET gold_g = ?, avg_cost_per_g = ?, updated_at = datetime('now') WHERE user_id = ?",
    newGold, newAvg, req.user.id
  );
  await db.run(
    "INSERT INTO savings_transactions(user_id,type,amount_toman,gold_g,gold_price_per_g) VALUES (?,?,?,?,?)",
    req.user.id, "buy_gold", amount, gold_g, price
  );

  res.json({ ok: true, gold_g, wallet: { gold_g: newGold, avg_cost_per_g: newAvg }, price_per_g: price });
});

// --- Orders / Checkout ---
const checkoutSchema = z.object({
  shipping_method: z.enum(["pickup","post"]).default("pickup"),
  shipping_address: z.string().optional(),
  note: z.string().optional(),
  pay_with_savings_gold_g: z.number().min(0).optional().default(0)
});

async function createNotification(userId, title, body) {
  await db.run("INSERT INTO notifications(user_id,title,body) VALUES (?,?,?)", userId, title, body);
  io.to(`user:${userId}`).emit("notify", { title, body });
}

app.post("/api/orders/checkout", authRequired, requireRole("buyer","admin"), async (req, res) => {
  const parsed = checkoutSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "BAD_REQUEST", details: parsed.error.flatten() });

  const cart = await ensureCart(req.user.id);
  const cartRows = await db.all(`
    SELECT ci.product_id, ci.qty, p.name, p.category, p.weight_g, p.labor_pct, p.seller_id
    FROM cart_items ci
    JOIN products p ON p.id = ci.product_id
    WHERE ci.cart_id = ? AND p.active = 1
  `, cart.id);

  if (!cartRows.length) return res.status(400).json({ error: "CART_EMPTY" });

  const goldPrice = gold.get().price_per_g;
  const items = cartRows.map(r => ({
    ...r,
    unit_price: computeProductPriceToman(r, goldPrice),
    weight_g: Number(r.weight_g)
  }));

  const subtotal = items.reduce((sum, it) => sum + it.unit_price * it.qty, 0);
  const totals = computeCartTotalsToman(subtotal, process.env.FEE_MODE || "buyer_discount");

  // Savings gold usage (optional)
  const payWithGold = Number(parsed.data.pay_with_savings_gold_g || 0);
  let savingsUsedToman = 0;
  if (payWithGold > 0) {
    await db.run("INSERT OR IGNORE INTO savings_wallets(user_id) VALUES (?)", req.user.id);
    const wallet = await db.get("SELECT gold_g, avg_cost_per_g FROM savings_wallets WHERE user_id = ?", req.user.id);
    const available = Number(wallet?.gold_g || 0);
    const use = Math.min(available, payWithGold);
    savingsUsedToman = use * goldPrice;

    await db.run(
      "UPDATE savings_wallets SET gold_g = ?, updated_at = datetime('now') WHERE user_id = ?",
      Math.max(0, available - use), req.user.id
    );
    await db.run(
      "INSERT INTO savings_transactions(user_id,type,amount_toman,gold_g,gold_price_per_g) VALUES (?,?,?,?,?)",
      req.user.id, "spend_gold", savingsUsedToman, use, goldPrice
    );
  }

  const finalTotal = Math.max(0, Math.round(totals.total - savingsUsedToman));

  // For simplicity: assign seller_id if all items belong to one seller, else null
  const sellerSet = new Set(items.map(i => i.seller_id).filter(Boolean));
  const seller_id = sellerSet.size === 1 ? Array.from(sellerSet)[0] : null;

  const orderRes = await db.run(
    `INSERT INTO orders(buyer_id,seller_id,status,shipping_method,shipping_address,gold_price_per_g,subtotal_amount,fee_amount,total_amount,note)
     VALUES (?,?,?,?,?,?,?,?,?,?)`,
    req.user.id,
    seller_id,
    "pending_payment",
    parsed.data.shipping_method,
    parsed.data.shipping_method === "post" ? (parsed.data.shipping_address || "") : null,
    goldPrice,
    totals.subtotal,
    totals.fee_amount,
    finalTotal,
    parsed.data.note || null
  );
  const orderId = orderRes.lastID;

  for (const it of items) {
    await db.run(
      "INSERT INTO order_items(order_id,product_id,qty,unit_price,weight_g) VALUES (?,?,?,?,?)",
      orderId, it.product_id, it.qty, it.unit_price, it.weight_g
    );
  }

  // Clear cart
  await db.run("DELETE FROM cart_items WHERE cart_id = ?", cart.id);

  // Notifications
  await createNotification(req.user.id, "ثبت سفارش", `سفارش #${orderId} ثبت شد و در انتظار پرداخت است.`);
  if (seller_id) {
    await createNotification(seller_id, "سفارش جدید", `سفارش جدید #${orderId} ثبت شد.`);
  }

  // Payment start
  const payment = await startPayment({ orderId, amountToman: finalTotal, req });

  res.json({ order_id: orderId, amount_toman: finalTotal, payment });
});

app.get("/api/orders", authRequired, async (req, res) => {
  const role = req.user.role;
  let rows;
  if (role === "buyer") {
    rows = await db.all("SELECT * FROM orders WHERE buyer_id = ? ORDER BY id DESC", req.user.id);
  } else if (role === "seller") {
    rows = await db.all("SELECT * FROM orders WHERE seller_id = ? ORDER BY id DESC", req.user.id);
  } else {
    rows = await db.all("SELECT * FROM orders ORDER BY id DESC LIMIT 200");
  }
  res.json({ items: rows });
});

app.get("/api/orders/:id", authRequired, async (req, res) => {
  const id = Number(req.params.id);
  const order = await db.get("SELECT * FROM orders WHERE id = ?", id);
  if (!order) return res.status(404).json({ error: "NOT_FOUND" });
  if (req.user.role === "buyer" && order.buyer_id !== req.user.id) return res.status(403).json({ error: "FORBIDDEN" });
  if (req.user.role === "seller" && order.seller_id !== req.user.id) return res.status(403).json({ error: "FORBIDDEN" });

  const items = await db.all(`
    SELECT oi.*, p.name, p.category
    FROM order_items oi
    JOIN products p ON p.id = oi.product_id
    WHERE oi.order_id = ?
  `, id);
  res.json({ order, items });
});

// --- Mock payment pages ---
app.get("/pay/mock/:orderId", async (req, res) => {
  const id = Number(req.params.orderId);
  const order = await db.get("SELECT * FROM orders WHERE id = ?", id);
  if (!order) return res.status(404).send("Order not found");

  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.end(`
    <html>
      <head><meta charset="utf-8"/><title>درگاه پرداخت امن (دمو)</title></head>
      <body style="font-family: sans-serif; direction: rtl; padding: 24px;">
        <h2>درگاه پرداخت امن (دمو)</h2>
        <p>مبلغ قابل پرداخت: <b>${order.total_amount.toLocaleString("fa-IR")}</b> تومان</p>
        <p>سفارش: #${order.id}</p>
        <form method="POST" action="/pay/mock/${order.id}/confirm">
          <button style="padding:12px 18px; font-size:16px;">پرداخت موفق (دمو)</button>
        </form>
        <p style="margin-top:16px; color:#555;">برای اتصال واقعی، provider را در backend/src/payment.js پیاده‌سازی کنید.</p>
      </body>
    </html>
  `);
});

app.post("/pay/mock/:orderId/confirm", express.urlencoded({ extended: false }), async (req, res) => {
  const id = Number(req.params.orderId);
  const order = await db.get("SELECT * FROM orders WHERE id = ?", id);
  if (!order) return res.status(404).send("Order not found");

  await db.run("UPDATE orders SET status = 'paid' WHERE id = ?", id);

  // Notify buyer/seller
  await createNotification(order.buyer_id, "پرداخت موفق", `پرداخت سفارش #${id} با موفقیت انجام شد.`);
  if (order.seller_id) await createNotification(order.seller_id, "پرداخت سفارش", `پرداخت سفارش #${id} انجام شد.`);

  const origin = process.env.CORS_ORIGIN || "http://localhost:5173";
  res.redirect(`${origin}/payment/success?order_id=${id}`);
});

// --- Invoice PDF ---
app.get("/api/orders/:id/invoice", authRequired, async (req, res) => {
  const id = Number(req.params.id);
  const order = await db.get("SELECT * FROM orders WHERE id = ?", id);
  if (!order) return res.status(404).json({ error: "NOT_FOUND" });

  if (req.user.role === "buyer" && order.buyer_id !== req.user.id) return res.status(403).json({ error: "FORBIDDEN" });
  if (req.user.role === "seller" && order.seller_id !== req.user.id) return res.status(403).json({ error: "FORBIDDEN" });

  const buyer = await db.get("SELECT name, phone, email FROM users WHERE id = ?", order.buyer_id);
  const items = await db.all(`
    SELECT oi.qty, oi.unit_price, oi.weight_g, p.name, p.category
    FROM order_items oi
    JOIN products p ON p.id = oi.product_id
    WHERE oi.order_id = ?
  `, id);

  res.setHeader("Content-Type", "application/pdf");
  res.setHeader("Content-Disposition", `inline; filename="invoice-${id}.pdf"`);

  const doc = new PDFDocument({ margin: 40 });
  doc.pipe(res);

  doc.fontSize(18).text("فاکتور رسمی با ضمانت", { align: "center" });
  doc.moveDown(0.5);
  doc.fontSize(12).text("وین طلا — پنجره ی واحد خرید و فروش طلا", { align: "center" });
  doc.moveDown();

  doc.fontSize(12).text(`شماره سفارش: #${order.id}`);
  doc.text(`تاریخ: ${formatPersianDate(order.created_at)}`);
  doc.text(`خریدار: ${buyer?.name || ""} | ${buyer?.phone || ""} | ${buyer?.email || ""}`);
  doc.text(`روش دریافت: ${order.shipping_method === "pickup" ? "دریافت حضوری" : "پست کالا"}`);
  if (order.shipping_method === "post") doc.text(`آدرس: ${order.shipping_address || ""}`);
  doc.moveDown();

  doc.fontSize(12).text("اقلام:", { underline: true });
  doc.moveDown(0.3);

  items.forEach((it, idx) => {
    const line = `${idx+1}) ${it.name} (${it.category}) — وزن: ${it.weight_g}g — تعداد: ${it.qty} — قیمت واحد: ${Math.round(it.unit_price).toLocaleString("fa-IR")} تومان`;
    doc.text(line);
  });

  doc.moveDown();
  doc.text(`قیمت لحظه‌ای طلا (هر گرم): ${Math.round(order.gold_price_per_g).toLocaleString("fa-IR")} تومان`);
  doc.text(`جمع جزء: ${Math.round(order.subtotal_amount).toLocaleString("fa-IR")} تومان`);
  doc.text(`کارمزد ۲٪: ${Math.round(order.fee_amount).toLocaleString("fa-IR")} تومان`);
  doc.text(`مبلغ نهایی: ${Math.round(order.total_amount).toLocaleString("fa-IR")} تومان`, { underline: true });

  doc.moveDown();
  doc.fontSize(11).text("ضمانت: کلیه کالاها با فاکتور رسمی و تضمین اصالت و عیار ارائه می‌شوند.", { align: "right" });
  doc.moveDown(0.5);
  doc.fontSize(10).fillColor("gray").text("پشتیبانی واتس‌اپ: " + (process.env.SUPPORT_WHATSAPP || ""), { align: "right" });

  doc.end();
});

// --- Notifications ---
app.get("/api/notifications", authRequired, async (req, res) => {
  const items = await db.all("SELECT * FROM notifications WHERE user_id = ? ORDER BY id DESC LIMIT 100", req.user.id);
  res.json({ items });
});

app.patch("/api/notifications/:id/read", authRequired, async (req, res) => {
  const id = Number(req.params.id);
  await db.run("UPDATE notifications SET is_read = 1 WHERE id = ? AND user_id = ?", id, req.user.id);
  res.json({ ok: true });
});

// --- Custom build requests ---
const customSchema = z.object({
  title: z.string().min(2),
  description: z.string().min(10),
  target_weight_g: z.number().positive().optional(),
  budget_toman: z.number().positive().optional()
});

app.post("/api/custom-requests", authRequired, requireRole("buyer","admin"), async (req, res) => {
  const parsed = customSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "BAD_REQUEST", details: parsed.error.flatten() });

  const { title, description, target_weight_g, budget_toman } = parsed.data;
  const r = await db.run(
    "INSERT INTO custom_requests(buyer_id,title,description,target_weight_g,budget_toman) VALUES (?,?,?,?,?)",
    req.user.id, title, description, target_weight_g || null, budget_toman || null
  );
  await createNotification(req.user.id, "درخواست ساخت ثبت شد", `درخواست #${r.lastID} ثبت شد.`);
  res.json({ id: r.lastID });
});

app.get("/api/custom-requests", authRequired, async (req, res) => {
  let items;
  if (req.user.role === "buyer") {
    items = await db.all("SELECT * FROM custom_requests WHERE buyer_id = ? ORDER BY id DESC", req.user.id);
  } else {
    items = await db.all("SELECT * FROM custom_requests ORDER BY id DESC LIMIT 200");
  }
  res.json({ items });
});

app.patch("/api/custom-requests/:id", authRequired, requireRole("seller","admin"), async (req, res) => {
  const id = Number(req.params.id);
  const status = z.enum(["reviewing","quoted","accepted","rejected","done"]).safeParse(req.body.status);
  if (!status.success) return res.status(400).json({ error: "BAD_REQUEST" });
  await db.run("UPDATE custom_requests SET status = ? WHERE id = ?", status.data, id);
  res.json({ ok: true });
});

// --- Analytics: profit chart ---
app.get("/api/analytics/profit-series", authRequired, requireRole("buyer","admin"), async (req, res) => {
  await db.run("INSERT OR IGNORE INTO savings_wallets(user_id) VALUES (?)", req.user.id);
  const wallet = await db.get("SELECT gold_g, avg_cost_per_g FROM savings_wallets WHERE user_id = ?", req.user.id);

  // holdings_g approximation: savings wallet + weights from paid orders
  const paidItems = await db.all(`
    SELECT oi.weight_g, oi.qty
    FROM order_items oi
    JOIN orders o ON o.id = oi.order_id
    WHERE o.buyer_id = ? AND o.status IN ('paid','processing','shipped','ready_for_pickup','completed')
  `, req.user.id);
  const ordersGold = paidItems.reduce((s, r) => s + Number(r.weight_g) * Number(r.qty), 0);

  const holdings_g = Number(wallet?.gold_g || 0) + ordersGold;

  // avg cost basis: use wallet avg cost; orders use their order gold price (approx)
  const paidOrders = await db.all(`
    SELECT gold_price_per_g, subtotal_amount, total_amount, created_at
    FROM orders
    WHERE buyer_id = ? AND status IN ('paid','processing','shipped','ready_for_pickup','completed')
    ORDER BY created_at ASC
  `, req.user.id);
  // approximate avg cost per g from orders
  let orderCost = 0;
  let orderGold = 0;
  for (const o of paidOrders) {
    // Estimate grams bought in that order = subtotal / price_per_g (ignores labor)
    const estG = Number(o.subtotal_amount) / Number(o.gold_price_per_g);
    orderGold += estG;
    orderCost += Number(o.total_amount);
  }
  const walletCost = Number(wallet?.gold_g || 0) * Number(wallet?.avg_cost_per_g || 0);
  const totalGold = (Number(wallet?.gold_g || 0) + orderGold) || 0;
  const avg_cost_per_g = totalGold > 0 ? (walletCost + orderCost) / totalGold : 0;

  // Get last 30 days price history (1 point per hour)
  const rows = await db.all(`
    SELECT price_per_g, created_at
    FROM gold_price_history
    WHERE created_at >= datetime('now', '-30 days')
    ORDER BY created_at ASC
  `);

  // downsample to ~720 points max
  const step = Math.max(1, Math.floor(rows.length / 720));
  const series = rows.filter((_, idx) => idx % step === 0).map(r => {
    const price = Number(r.price_per_g);
    const profit = holdings_g * (price - avg_cost_per_g);
    return { t: r.created_at, price_per_g: price, profit_toman: Math.round(profit) };
  });

  res.json({ holdings_g, avg_cost_per_g, series, current: gold.get() });
});

// --- Start ---
async function bootstrap() {
  if (!process.env.JWT_SECRET) {
    console.error("JWT_SECRET missing. Set it in .env");
    process.exit(1);
  }
  db = await openDb();
  await initDb(db);

  gold = new GoldPriceService({ db, io });
  await gold.start();

  const port = Number(process.env.PORT || 4000);
  server.listen(port, () => console.log(`Backend running on http://localhost:${port}`));
}

bootstrap().catch((e) => {
  console.error(e);
  process.exit(1);
});

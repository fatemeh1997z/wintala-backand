export function toToman(n) {
  // Keep as number; frontend formats
  return Math.round(Number(n) || 0);
}

export function nowIso() {
  return new Date().toISOString();
}

export function clamp(n, min, max) {
  return Math.max(min, Math.min(max, n));
}

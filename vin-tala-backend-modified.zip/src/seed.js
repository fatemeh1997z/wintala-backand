import "dotenv/config";
import { openDb, initDb } from "./src/db.js";
import { hashPassword } from "./src/auth.js";

function rand(arr) { return arr[Math.floor(Math.random()*arr.length)]; }

const categories = [
  "گوشواره","النگو","انگشتر","گردنبند","دستبند","سرویس","زنجیر","آویز","سکه","شمش","پک سرمایه‌گذاری"
];

const sampleTexts = [
  "کیفیت ساخت خیلی خوب بود و بسته‌بندی عالی.",
  "به‌موقع رسید. وزن و ظاهر مطابق توضیحات.",
  "برای هدیه گرفتم، خیلی شیکه.",
  "پشتیبانی پاسخ‌گو بود. تجربه خرید خوب.",
  "کار تمیز و ظریف. ممنون."
];

async function upsertUser(db, { role, name, email, password, phone }) {
  const existing = await db.get("SELECT id FROM users WHERE email = ?", email);
  if (existing) return existing.id;
  const hash = await hashPassword(password);
  const r = await db.run(
    "INSERT INTO users(role,name,email,phone,password_hash) VALUES (?,?,?,?,?)",
    role, name, email, phone || null, hash
  );
  await db.run("INSERT OR IGNORE INTO carts(user_id) VALUES (?)", r.lastID);
  await db.run("INSERT OR IGNORE INTO savings_wallets(user_id) VALUES (?)", r.lastID);
  return r.lastID;
}

async function main() {
  const db = await openDb();
  await initDb(db);

  const adminId = await upsertUser(db, { role:"admin", name:"ادمین وین طلا", email:"admin@vintala.local", password:"Admin123!", phone:"09120000000" });
  const sellerId = await upsertUser(db, { role:"seller", name:"فروشنده نمونه", email:"seller@vintala.local", password:"Seller123!", phone:"09121111111" });
  const buyerId  = await upsertUser(db, { role:"buyer", name:"خریدار نمونه", email:"buyer@vintala.local", password:"Buyer123!", phone:"09122222222" });

  // Clear products & reviews for reseed
  await db.exec("DELETE FROM reviews;");
  await db.exec("DELETE FROM products;");

  const products = [];

  // 28 regular products
  for (let i=1; i<=28; i++) {
    const cat = rand(categories.filter(c => c !== "پک سرمایه‌گذاری"));
    const weight = Number((Math.random()*15 + 1.2).toFixed(2)); // 1.2g - 16.2g
    const labor = Number((Math.random()*10 + 4).toFixed(1)); // 4% - 14%
    products.push({
      seller_id: sellerId,
      name: `محصول ${i} - ${cat}`,
      category: cat,
      weight_g: weight,
      labor_pct: labor,
      image_url: `https://picsum.photos/seed/vintala-${i}/600/600`,
      description: "طراحی ویژه وین طلا. از دل کارگاه تو دست تو.",
      active: 1
    });
  }

  // 2 investment packs (500g and 1000g)
  products.push({
    seller_id: sellerId,
    name: "پک نیم کیلویی سرمایه‌گذاری (500 گرم)",
    category: "پک سرمایه‌گذاری",
    weight_g: 500,
    labor_pct: 0,
    image_url: `https://picsum.photos/seed/vintala-pack-500/600/600`,
    description: "پک سرمایه‌گذاری نیم کیلویی (طلا/شمش) مناسب پس‌انداز.",
    active: 1
  });
  products.push({
    seller_id: sellerId,
    name: "پک یک کیلویی سرمایه‌گذاری (1000 گرم)",
    category: "پک سرمایه‌گذاری",
    weight_g: 1000,
    labor_pct: 0,
    image_url: `https://picsum.photos/seed/vintala-pack-1000/600/600`,
    description: "پک سرمایه‌گذاری یک کیلویی (طلا/شمش) مناسب سرمایه‌گذاری.",
    active: 1
  });

  for (const p of products) {
    const r = await db.run(
      "INSERT INTO products(seller_id,name,category,weight_g,labor_pct,image_url,description,active) VALUES (?,?,?,?,?,?,?,?)",
      p.seller_id, p.name, p.category, p.weight_g, p.labor_pct, p.image_url, p.description, p.active
    );
    const pid = r.lastID;
    // seed sample reviews (safe demo)
    const demoMode = (process.env.DEMO_MODE || "true") === "true";
    const count = demoMode ? 3 : 0;
    for (let k=0; k<count; k++) {
      const rating = rand([4,5,5,5,4]);
      const text = rand(sampleTexts);
      await db.run(
        "INSERT INTO reviews(product_id,user_id,rating,text,is_sample) VALUES (?,?,?,?,1)",
        pid, buyerId, rating, text
      );
    }
  }

  console.log("Seed done. Users:", { adminId, sellerId, buyerId, products: products.length });
  process.exit(0);
}

main().catch((e)=>{ console.error(e); process.exit(1); });
